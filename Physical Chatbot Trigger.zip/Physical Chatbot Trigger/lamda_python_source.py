
import json
import os
import uuid
import boto3
import urllib.request
import urllib.error
from datetime import datetime, timezone

# AWS DynamoDB connection
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(
    os.environ.get("DYNAMODB_TABLE", "Physical-Chatbot-Events")
)


def lambda_handler(event, context):

    webhook_url = os.environ.get("DISCORD_WEBHOOK_URL")

    if not webhook_url:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": "Discord webhook URL not configured"
            })
        }

    # Handle API Gateway and direct Lambda test events
    if isinstance(event.get("body"), str):
        try:
            request_data = json.loads(event["body"])
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Invalid JSON body"})
            }
    else:
        request_data = event

    message = request_data.get(
        "message",
        "Physical Chatbot Trigger activated!"
    )

    if not isinstance(message, str) or not message.strip():
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Message cannot be empty"})
        }

    message = message.strip()

    # Generate event details
    event_id = str(uuid.uuid4())
    timestamp = datetime.now(timezone.utc).isoformat()

    status = "Failed"
    error_details = None

    # Send notification to Discord
    payload = {"content": message}
    data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(
        webhook_url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "User-Agent": "PhysicalChatbotTrigger/1.0"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            print("Discord Response:", response.status)
            status = "Success"

    except urllib.error.HTTPError as error:
        error_details = error.read().decode("utf-8")
        print("Discord HTTP Error:", error.code)
        print("Discord Details:", error_details)

    except urllib.error.URLError as error:
        error_details = str(error.reason)
        print("Connection Error:", error_details)

    except Exception as error:
        error_details = str(error)
        print("Unexpected Error:", error_details)

    # Store event in DynamoDB
    item = {
        "event_id": event_id,
        "message": message,
        "timestamp": timestamp,
        "status": status,
        "source": "Virtual Button"
    }

    if error_details:
        item["error"] = error_details

    try:
        table.put_item(Item=item)
        print("Event saved to DynamoDB:", event_id)

    except Exception as error:
        print("DynamoDB Error:", str(error))

        return {
            "statusCode": 500,
            "body": json.dumps({
                "status": status,
                "error": "Failed to save event to DynamoDB",
                "details": str(error),
                "event_id": event_id
            })
        }

    # Return final result
    if status == "Success":
        return {
            "statusCode": 200,
            "body": json.dumps({
                "status": "Success",
                "message": "Discord notification sent and event saved!",
                "event_id": event_id
            })
        }

    return {
        "statusCode": 502,
        "body": json.dumps({
            "status": "Failed",
            "error": error_details,
            "event_id": event_id
        })
    }
