
const sendButton = document.getElementById("sendButton");
const messageInput = document.getElementById("message");
const statusText = document.getElementById("status");

// Replace this with our actual API Gateway endpoint
const API_URL = "https://ey3jxjdjy2.execute-api.ap-southeast-2.amazonaws.com/default/Physical-Chatbot-Trigger";

sendButton.addEventListener("click", async function () {

    const message = messageInput.value.trim();

    if (message === "") {
        statusText.textContent = "Please enter a message!";
        statusText.style.color = "#f87171";
        return;
    }

    sendButton.disabled = true;
    sendButton.textContent = "Sending...";
    statusText.textContent = "";

    try {

        const response = await fetch(API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                message: message
            })
        });

        const result = await response.json();

        if (!response.ok || result.status !== "Success") {
            throw new Error(result.error || "Message delivery failed");
        }

        statusText.textContent = "Message sent successfully!";
        statusText.style.color = "#4ade80";

        messageInput.value = "";

    } catch (error) {

        statusText.textContent = "Error: " + error.message;
        statusText.style.color = "#f87171";

    } finally {

        sendButton.disabled = false;
        sendButton.textContent = "Send Message";

    }

});
